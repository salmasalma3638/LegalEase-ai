"""
Central configuration for LegalEase.
Loads environment variables once so every module reads consistent values.
"""
import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

BACKEND_HOST = os.getenv("BACKEND_HOST", "0.0.0.0")
BACKEND_PORT = int(os.getenv("BACKEND_PORT", "8000"))
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

# Shown on every generated document and in the UI. Do not remove —
# this app produces AI-drafted starting points, not vetted legal advice.
LEGAL_DISCLAIMER = (
    "This document was drafted with AI assistance and has not been reviewed "
    "by a licensed attorney. It may contain errors, omissions, or clauses "
    "that are unenforceable in your jurisdiction. Have a qualified lawyer "
    "review this document before signing or relying on it."
)

COMPANY_NAME = "LegalEase Inc."
COMPANY_CONTACT = "contact@legalease.com"

LOGO_PATH = os.path.join(os.path.dirname(__file__), "Image", "Logo.png")
