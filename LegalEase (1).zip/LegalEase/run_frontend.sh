#!/usr/bin/env bash
# Starts the Streamlit frontend. Run from the project root.
set -e
streamlit run frontend/app.py
