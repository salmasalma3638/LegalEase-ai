"""
test_smoke.py

Lightweight offline sanity checks — no Gemini API calls, no network.
Run from the project root:
    python test_smoke.py

For full end-to-end testing (which DOES call Gemini and costs quota),
start the backend and frontend, then use the UI or the curl example in
README.md.
"""
import sys

from frontend.formatters import sanitize_text, format_docx, format_pdf, format_html_preview
from ai_core.gemini_generator import GeminiDocumentGenerator

SAMPLE_TEXT = """## Freelance Work Contract

### 1. Parties
Jane Doe ("Service Provider") and TechNova Inc. ("Client").

- Payment due within 30 days of invoice
- Confidentiality must be maintained at all times

### 2. Term
This agreement is effective as of April 15, 2025.
"""


def check(label, condition):
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {label}")
    return condition


def main():
    all_ok = True

    cleaned = sanitize_text("Hello \u2018world\u2019 \u2014 test")
    all_ok &= check("sanitize_text strips typographic quotes", "'" in cleaned and "\u2018" not in cleaned)

    docx_bytes = format_docx(SAMPLE_TEXT, "Freelance Work Contract", "Payment due within 30 days; Confidentiality required")
    all_ok &= check("format_docx returns non-empty bytes", isinstance(docx_bytes, bytes) and len(docx_bytes) > 1000)

    pdf_bytes = format_pdf(SAMPLE_TEXT, "Freelance Work Contract", "Payment due within 30 days; Confidentiality required")
    all_ok &= check("format_pdf returns non-empty bytes", isinstance(pdf_bytes, bytes) and len(pdf_bytes) > 500)

    html = format_html_preview(SAMPLE_TEXT)
    all_ok &= check("format_html_preview produces HTML", "<h3" in html)

    generator = GeminiDocumentGenerator()
    prompt = generator._build_prompt(  # noqa: SLF001 (internal, but fine for a smoke test)
        "Non-Disclosure Agreement", "Jane Doe, TechNova Inc.", "Confidentiality for 2 years", "April 15, 2025"
    )
    all_ok &= check("prompt includes NDA-specific guidance", "NON-DISCLOSURE AGREEMENT" in prompt)
    all_ok &= check("prompt flags missing jurisdiction instead of inventing one", "NOT PROVIDED" in prompt)

    if all_ok:
        print("\nAll smoke tests passed.")
        sys.exit(0)
    else:
        print("\nSome smoke tests FAILED.")
        sys.exit(1)


if __name__ == "__main__":
    main()
