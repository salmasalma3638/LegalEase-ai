"""
ai_core/gemini_generator.py

Wraps the Google Gemini API to draft legal document text.

Design notes (why this differs from a single generic prompt):
- Each document type gets its own instruction block naming the clauses
  that type must include. A single freeform prompt tends to produce
  inconsistent or missing sections across runs.
- Every prompt requires the model to explicitly flag any information it
  had to invent with an [ASSUMED: ...] tag, and to never silently leave
  a bracket placeholder unexplained.
- Network/API failures are caught and turned into a clear exception the
  API layer can translate into a clean HTTP error instead of a 500 crash.
"""
import os
import sys
import time
import logging

import google.generativeai as genai

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import GEMINI_API_KEY, GEMINI_MODEL, LEGAL_DISCLAIMER  # noqa: E402

logger = logging.getLogger("legalease.gemini")

MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = 2


class DocumentGenerationError(Exception):
    """Raised when Gemini cannot produce a document after retries."""


# Per-document-type clause checklists. Keys are matched against a
# normalized (lowercased) version of the user's document_type input.
DOCUMENT_TYPE_GUIDANCE = {
    "employment": (
        "This is an EMPLOYMENT CONTRACT / OFFER LETTER. Include, at minimum: "
        "job title and duties, start date, compensation and pay schedule, "
        "benefits (if any terms provided), work location/hours, "
        "confidentiality obligations, at-will or fixed-term status, "
        "termination conditions, and a signature block for both parties."
    ),
    "nda": (
        "This is a NON-DISCLOSURE AGREEMENT (NDA). Include, at minimum: "
        "definition of 'Confidential Information', obligations of the "
        "receiving party, exclusions from confidentiality (e.g. public "
        "information, independently developed information), term/duration "
        "of the obligation, remedies for breach, and a signature block. "
        "State clearly whether this is a one-way or mutual NDA based on the "
        "parties described."
    ),
    "lease": (
        "This is a RESIDENTIAL LEASE AGREEMENT. Include, at minimum: "
        "property address, landlord and tenant names, lease term/duration, "
        "rent amount and due date, security deposit terms, maintenance "
        "responsibilities, rules on subletting, grounds for termination, "
        "and a signature block."
    ),
    "contract": (
        "This is a GENERAL SERVICE CONTRACT. Include, at minimum: scope of "
        "services/deliverables, payment terms, timeline/milestones, "
        "intellectual property ownership, termination conditions, "
        "liability limitations, and a signature block."
    ),
    "agreement": (
        "This is a GENERAL AGREEMENT. Include, at minimum: purpose of the "
        "agreement, obligations of each party, term/duration, termination "
        "conditions, and a signature block."
    ),
}

DEFAULT_GUIDANCE = (
    "Include the clauses standard for this type of legal document, a "
    "clear statement of each party's obligations, term/termination "
    "conditions, and a signature block."
)


def _select_guidance(document_type: str) -> str:
    normalized = document_type.lower()
    for keyword, guidance in DOCUMENT_TYPE_GUIDANCE.items():
        if keyword in normalized:
            return guidance
    return DEFAULT_GUIDANCE


class GeminiDocumentGenerator:
    def __init__(self):
        if not GEMINI_API_KEY:
            logger.warning(
                "GEMINI_API_KEY is not set. Set it in your .env file before "
                "calling generate_document()."
            )
        genai.configure(api_key=GEMINI_API_KEY)
        self.model_name = GEMINI_MODEL
        self.model = genai.GenerativeModel(self.model_name)

    def _build_prompt(
        self,
        document_type: str,
        parties: str,
        terms: str,
        dates: str,
        jurisdiction: str = "",
    ) -> str:
        guidance = _select_guidance(document_type)
        jurisdiction_line = (
            f"Governing law / jurisdiction: {jurisdiction}\n"
            if jurisdiction.strip()
            else (
                "Governing law / jurisdiction: NOT PROVIDED. Leave the "
                "governing-law clause as the placeholder "
                "'[GOVERNING LAW - TO BE SPECIFIED]' rather than inventing "
                "a state or country.\n"
            )
        )

        prompt = (
            f"You are drafting a {document_type} for a non-lawyer user of a "
            "document-generation tool. Draft clear, professional, plain-"
            "English legal text.\n\n"
            f"{guidance}\n\n"
            "Details provided by the user:\n"
            f"- Parties involved: {parties}\n"
            f"- {jurisdiction_line}"
            f"- Effective date: {dates}\n"
            f"- Terms and conditions requested: {terms}\n\n"
            "Formatting rules:\n"
            "1. Use a numbered section for each major clause with a bold "
            "heading (Markdown ## for the title, ### for section headers).\n"
            "2. If a necessary detail was not supplied (e.g. an address, a "
            "dollar amount, a notice period), insert a clearly bracketed "
            "placeholder like [PROPERTY ADDRESS] rather than inventing a "
            "specific value.\n"
            "3. Do not state or imply that this document has been reviewed "
            "by an attorney or is guaranteed to be legally enforceable.\n"
            "4. End the document with a signature block for every party "
            "named.\n"
            "5. Output only the document text (Markdown-formatted). Do not "
            "add commentary before or after it.\n"
        )
        return prompt

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: str,
        dates: str,
        jurisdiction: str = "",
    ) -> str:
        """
        Calls Gemini to draft the document text. Retries transient failures
        with exponential backoff. Raises DocumentGenerationError if all
        attempts fail, so the API layer can return a clean error instead of
        crashing.
        """
        if not GEMINI_API_KEY:
            raise DocumentGenerationError(
                "Server is not configured with a GEMINI_API_KEY. "
                "Set it in the .env file and restart the backend."
            )

        prompt = self._build_prompt(document_type, parties, terms, dates, jurisdiction)

        last_error = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = self.model.generate_content(prompt)
                text = getattr(response, "text", None)
                if not text or not text.strip():
                    raise DocumentGenerationError(
                        "Gemini returned an empty response."
                    )
                # Append the disclaimer as plain text; formatters also add
                # a styled version, but this guarantees it survives even
                # plain .txt exports of the raw generated string.
                return f"{text.strip()}\n\n---\n{LEGAL_DISCLAIMER}"
            except DocumentGenerationError:
                raise
            except Exception as exc:  # network errors, API errors, etc.
                last_error = exc
                logger.warning(
                    "Gemini call failed (attempt %s/%s): %s",
                    attempt,
                    MAX_RETRIES,
                    exc,
                )
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF_SECONDS * attempt)

        raise DocumentGenerationError(
            f"Failed to generate document after {MAX_RETRIES} attempts: {last_error}"
        )
