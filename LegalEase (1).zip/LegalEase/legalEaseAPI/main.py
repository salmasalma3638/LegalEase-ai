"""
legalEaseAPI/main.py

FastAPI application entrypoint. Run with:
    uvicorn legalEaseAPI.main:app --reload
from the project root.
"""
import os
import sys
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from legalEaseAPI.routes import router  # noqa: E402

logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="LegalEase - AI Legal Document Generator",
    description=(
        "Generates draft legal documents with Gemini. Output is a starting "
        "point only and is not a substitute for review by a licensed "
        "attorney."
    ),
    version="1.0.0",
)

# Allow the Streamlit frontend (different port/origin) to call this API.
# Tighten allow_origins to your actual frontend URL(s) before deploying
# beyond localhost.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:8501",
        "http://127.0.0.1:8501",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get("/")
def home():
    return {"message": "Welcome to LegalEase AI Legal Document Generator API"}


if __name__ == "__main__":
    import uvicorn
    from config import BACKEND_HOST, BACKEND_PORT

    uvicorn.run("legalEaseAPI.main:app", host=BACKEND_HOST, port=BACKEND_PORT, reload=True)
