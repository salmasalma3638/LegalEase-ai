"""
legalEaseAPI/routes.py

Defines the /generate endpoint. Validates input with Pydantic, calls the
Gemini generator, and translates generation failures into clean HTTP errors
instead of letting exceptions crash the request.
"""
import os
import sys

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_core.gemini_generator import GeminiDocumentGenerator, DocumentGenerationError  # noqa: E402

router = APIRouter()
gemini_generator = GeminiDocumentGenerator()


class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=200)
    parties: str = Field(..., min_length=2, max_length=2000)
    terms: str = Field(..., min_length=2, max_length=5000)
    dates: str = Field(..., min_length=2, max_length=100)
    jurisdiction: str = Field(default="", max_length=200)

    @field_validator("document_type", "parties", "terms", "dates")
    @classmethod
    def not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("This field cannot be blank.")
        return value.strip()


class DocumentResponse(BaseModel):
    document: str
    document_type: str
    model_used: str


@router.post("/generate", response_model=DocumentResponse)
def generate_legal_document(request: DocumentRequest):
    try:
        generated_text = gemini_generator.generate_document(
            document_type=request.document_type,
            parties=request.parties,
            terms=request.terms,
            dates=request.dates,
            jurisdiction=request.jurisdiction,
        )
    except DocumentGenerationError as exc:
        # Known, expected failure mode (bad/missing API key, Gemini outage,
        # empty response) -> return a clean 502 instead of a stack trace.
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:  # truly unexpected
        raise HTTPException(
            status_code=500, detail=f"Unexpected server error: {exc}"
        ) from exc

    return DocumentResponse(
        document=generated_text,
        document_type=request.document_type,
        model_used=gemini_generator.model_name,
    )


@router.get("/health")
def health_check():
    return {"status": "ok"}
