#!/usr/bin/env bash
# Starts the FastAPI backend. Run from the project root.
set -e
uvicorn legalEaseAPI.main:app --reload --host 0.0.0.0 --port 8000
