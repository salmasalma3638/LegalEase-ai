"""
frontend/formatters.py

Converts raw AI-generated Markdown-ish text into:
- sanitize_text(text): cleans typographic quotes/special chars
- format_docx(text, doc_type): branded .docx via python-docx
- format_pdf(text, doc_type): branded .pdf via fpdf2
- format_html_preview(text): styled HTML for the Streamlit preview card

All exports include the legal disclaimer in the footer/body so it survives
regardless of which format the user downloads.
"""
import io
import os
import re
import sys

from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from fpdf import FPDF

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LEGAL_DISCLAIMER, COMPANY_NAME, COMPANY_CONTACT, LOGO_PATH  # noqa: E402


def sanitize_text(text: str) -> str:
    """Removes typographic quotes/dashes and stray control characters."""
    if not text:
        return ""
    replacements = {
        "\u2018": "'", "\u2019": "'",
        "\u201c": '"', "\u201d": '"',
        "\u2013": "-", "\u2014": "-",
        "\u2026": "...",
    }
    for bad, good in replacements.items():
        text = text.replace(bad, good)
    # strip other non-printable/control characters except newlines/tabs
    text = re.sub(r"[^\x09\x0A\x0D\x20-\x7E]", "", text)
    return text.strip()


def _split_terms(terms_raw: str):
    """Splits a semicolon-separated terms string into clean bullet items."""
    if not terms_raw:
        return []
    return [t.strip() for t in terms_raw.split(";") if t.strip()]


def _parse_lines(text: str):
    """
    Very light Markdown-ish parser: distinguishes level-1 headings (##),
    level-2 headings (###), and body paragraphs. Good enough for the
    structured output the prompt asks Gemini to produce.
    """
    lines = []
    for raw_line in text.split("\n"):
        line = raw_line.rstrip()
        if not line.strip():
            lines.append(("blank", ""))
        elif line.startswith("### "):
            lines.append(("h2", line[4:].strip()))
        elif line.startswith("## "):
            lines.append(("h1", line[3:].strip()))
        elif line.startswith("- ") or line.startswith("* "):
            lines.append(("bullet", line[2:].strip()))
        else:
            lines.append(("body", line.strip()))
    return lines


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------
def format_docx(text: str, doc_type: str, terms_raw: str = "") -> bytes:
    text = sanitize_text(text)
    document = Document()

    style = document.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(11)

    if os.path.exists(LOGO_PATH):
        logo_paragraph = document.add_paragraph()
        logo_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = logo_paragraph.add_run()
        try:
            run.add_picture(LOGO_PATH, width=Inches(1.3))
        except Exception:
            pass  # corrupt/unsupported image -> skip silently, don't crash export

    title = document.add_heading(doc_type.strip() or "Legal Document", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    for kind, content in _parse_lines(text):
        if kind == "h1":
            document.add_heading(content, level=1)
        elif kind == "h2":
            document.add_heading(content, level=2)
        elif kind == "bullet":
            document.add_paragraph(content, style="List Bullet")
        elif kind == "body" and content:
            document.add_paragraph(content)
        # blank lines intentionally skipped; headings/paragraphs give spacing

    terms_list = _split_terms(terms_raw)
    if terms_list:
        document.add_heading("Terms & Conditions (Summary Table)", level=1)
        table = document.add_table(rows=1, cols=2)
        table.style = "Light Grid Accent 1"
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = "#"
        hdr_cells[1].text = "Term"
        for idx, term in enumerate(terms_list, start=1):
            row_cells = table.add_row().cells
            row_cells[0].text = str(idx)
            row_cells[1].text = term

    document.add_page_break()
    footer_heading = document.add_paragraph()
    footer_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_run = footer_heading.add_run("Important Notice")
    footer_run.bold = True

    disclaimer_para = document.add_paragraph(LEGAL_DISCLAIMER)
    disclaimer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

    contact_para = document.add_paragraph(f"{COMPANY_NAME} | {COMPANY_CONTACT}")
    contact_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

    buffer = io.BytesIO()
    document.save(buffer)
    buffer.seek(0)
    return buffer.read()


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------
class _BrandedPDF(FPDF):
    def __init__(self, doc_type: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.doc_type = doc_type or "Legal Document"

    def header(self):
        if os.path.exists(LOGO_PATH):
            try:
                self.image(LOGO_PATH, x=(self.w - 25) / 2, y=8, w=25)
                self.ln(22)
            except Exception:
                self.ln(4)
        self.set_font("Helvetica", "B", 14)
        self.cell(0, 10, self.doc_type, align="C", new_x="LMARGIN", new_y="NEXT")
        self.ln(2)

    def footer(self):
        self.set_y(-20)
        self.set_font("Helvetica", "I", 7)
        self.set_text_color(120, 120, 120)
        self.multi_cell(0, 4, LEGAL_DISCLAIMER, align="C")
        self.set_font("Helvetica", "", 7)
        self.cell(0, 4, f"{COMPANY_NAME} | {COMPANY_CONTACT}", align="C")


def _pdf_safe(text: str) -> str:
    # fpdf2's core fonts (Helvetica) are latin-1 only; replace anything
    # outside that range instead of crashing the export.
    return text.encode("latin-1", "replace").decode("latin-1")


def format_pdf(text: str, doc_type: str, terms_raw: str = "") -> bytes:
    text = sanitize_text(text)
    pdf = _BrandedPDF(doc_type=doc_type.strip() or "Legal Document")
    pdf.set_auto_page_break(auto=True, margin=25)
    pdf.add_page()
    pdf.set_font("Helvetica", "", 11)

    for kind, content in _parse_lines(text):
        content = _pdf_safe(content)
        if kind == "h1":
            pdf.set_font("Helvetica", "B", 13)
            pdf.ln(2)
            pdf.multi_cell(0, 7, content)
            pdf.set_font("Helvetica", "", 11)
        elif kind == "h2":
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 6, content)
            pdf.set_font("Helvetica", "", 11)
        elif kind == "bullet":
            pdf.multi_cell(0, 6, f"  - {content}")
        elif kind == "body" and content:
            pdf.multi_cell(0, 6, content)
        else:
            pdf.ln(2)

    terms_list = _split_terms(terms_raw)
    if terms_list:
        pdf.ln(4)
        pdf.set_font("Helvetica", "B", 12)
        pdf.multi_cell(0, 7, "Terms & Conditions (Summary)")
        pdf.set_font("Helvetica", "", 11)
        for term in terms_list:
            pdf.multi_cell(0, 6, f"  - {_pdf_safe(term)}")

    output = pdf.output()
    return bytes(output)


# ---------------------------------------------------------------------------
# HTML preview
# ---------------------------------------------------------------------------
def format_html_preview(text: str) -> str:
    text = sanitize_text(text)
    html_parts = []
    in_list = False

    for kind, content in _parse_lines(text):
        content_escaped = (
            content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        if kind == "bullet":
            if not in_list:
                html_parts.append("<ul style='margin:4px 0 4px 20px;'>")
                in_list = True
            html_parts.append(f"<li>{content_escaped}</li>")
            continue
        else:
            if in_list:
                html_parts.append("</ul>")
                in_list = False

        if kind == "h1":
            html_parts.append(
                f"<h3 style='color:#e8e8e8;border-bottom:1px solid #444;"
                f"padding-bottom:4px;margin-top:18px;'>{content_escaped}</h3>"
            )
        elif kind == "h2":
            html_parts.append(
                f"<h4 style='color:#d8d8d8;margin-top:12px;'>{content_escaped}</h4>"
            )
        elif kind == "body" and content_escaped:
            html_parts.append(
                f"<p style='color:#cfcfcf;line-height:1.5;margin:6px 0;'>{content_escaped}</p>"
            )
        else:
            html_parts.append("<div style='height:6px;'></div>")

    if in_list:
        html_parts.append("</ul>")

    return "\n".join(html_parts)
