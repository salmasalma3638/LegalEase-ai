"""
frontend/app.py

Streamlit UI for LegalEase. Run with:
    streamlit run frontend/app.py
from the project root.
"""
import os
import sys

import requests
import streamlit as st

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BACKEND_URL, LEGAL_DISCLAIMER, LOGO_PATH  # noqa: E402
from frontend.formatters import (  # noqa: E402
    sanitize_text,
    format_docx,
    format_pdf,
    format_html_preview,
)

st.set_page_config(page_title="LegalEase", layout="centered")

# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    if os.path.exists(LOGO_PATH):
        st.image(LOGO_PATH, use_container_width=True)
    else:
        st.markdown(
            "<h1 style='text-align:center;'>&#9878; LegalEase</h1>",
            unsafe_allow_html=True,
        )

st.markdown(
    "<h2 style='text-align:center;'>AI Legal Document Generator</h2>",
    unsafe_allow_html=True,
)

st.warning(f"**Disclaimer:** {LEGAL_DISCLAIMER}", icon="⚠️")

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "generated_text" not in st.session_state:
    st.session_state.generated_text = ""
if "show_edit" not in st.session_state:
    st.session_state.show_edit = False
if "last_doc_type" not in st.session_state:
    st.session_state.last_doc_type = ""
if "last_terms" not in st.session_state:
    st.session_state.last_terms = ""

# ---------------------------------------------------------------------------
# Input form
# ---------------------------------------------------------------------------
DOC_TYPE_PRESETS = [
    "Employment Contract",
    "Non-Disclosure Agreement (NDA)",
    "Residential Lease Agreement",
    "Freelance / Service Contract",
    "General Agreement",
    "Other (type below)",
]

preset = st.selectbox("Document Type", DOC_TYPE_PRESETS, index=0)
if preset == "Other (type below)":
    document_type = st.text_input("Enter custom document type", placeholder="e.g. Partnership Agreement")
else:
    document_type = preset

parties = st.text_area(
    "Parties Involved",
    placeholder="e.g. Jane Doe (Service Provider), TechNova Inc. (Client)",
    height=80,
)

jurisdiction = st.text_input(
    "Governing Law / Jurisdiction (recommended)",
    placeholder="e.g. State of Delaware, USA",
    help="If left blank, the document will use a placeholder instead of "
    "guessing a jurisdiction.",
)

terms = st.text_area(
    "Terms & Conditions (use semicolons to separate clauses)",
    placeholder="Payment due within 30 days of invoice; Confidentiality must be maintained at all times; ...",
    height=120,
)

dates = st.text_input("Effective Date", placeholder="e.g. April 15, 2025")

generate_clicked = st.button("Generate Document", type="primary")

status_placeholder = st.empty()

if generate_clicked:
    if not document_type.strip() or not parties.strip() or not terms.strip() or not dates.strip():
        status_placeholder.error("Please fill in all fields before generating.")
    else:
        with st.spinner("Drafting your document with Gemini..."):
            try:
                response = requests.post(
                    f"{BACKEND_URL}/generate",
                    json={
                        "document_type": document_type,
                        "parties": parties,
                        "terms": terms,
                        "dates": dates,
                        "jurisdiction": jurisdiction,
                    },
                    timeout=60,
                )
                if response.status_code == 200:
                    data = response.json()
                    st.session_state.generated_text = sanitize_text(data["document"])
                    st.session_state.last_doc_type = document_type
                    st.session_state.last_terms = terms
                    st.session_state.show_edit = False
                    status_placeholder.success("Document Generated Successfully!")
                else:
                    detail = response.json().get("detail", response.text)
                    status_placeholder.error(f"Generation failed ({response.status_code}): {detail}")
            except requests.exceptions.ConnectionError:
                status_placeholder.error(
                    "Could not reach the backend. Is it running at "
                    f"{BACKEND_URL}? Start it with: uvicorn legalEaseAPI.main:app --reload"
                )
            except requests.exceptions.Timeout:
                status_placeholder.error("The request timed out. Please try again.")
            except Exception as exc:
                status_placeholder.error(f"Unexpected error: {exc}")

# ---------------------------------------------------------------------------
# Preview / edit / download
# ---------------------------------------------------------------------------
if st.session_state.generated_text:
    styled_html = format_html_preview(st.session_state.generated_text)
    st.markdown(
        f"<div style='background:#12151a;border:1px solid #333;border-radius:8px;"
        f"padding:18px 22px;max-height:480px;overflow-y:auto;'>{styled_html}</div>",
        unsafe_allow_html=True,
    )

    if st.button("Click to Edit Document"):
        st.session_state.show_edit = not st.session_state.show_edit

    if st.session_state.show_edit:
        edited_text = st.text_area(
            "Edit Document Below:",
            value=st.session_state.generated_text,
            height=300,
        )
        st.session_state.generated_text = edited_text

    st.markdown("#### Download / Save")
    safe_filename = (
        st.session_state.last_doc_type.replace(" ", "_").replace("/", "-").lower() or "document"
    )

    dl_col1, dl_col2, dl_col3 = st.columns(3)
    with dl_col1:
        st.download_button(
            "📄 Download as .TXT",
            data=st.session_state.generated_text,
            file_name=f"{safe_filename}.txt",
            mime="text/plain",
        )
    with dl_col2:
        docx_bytes = format_docx(
            st.session_state.generated_text,
            st.session_state.last_doc_type,
            st.session_state.last_terms,
        )
        st.download_button(
            "📝 Download as .DOCX",
            data=docx_bytes,
            file_name=f"{safe_filename}.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
    with dl_col3:
        pdf_bytes = format_pdf(
            st.session_state.generated_text,
            st.session_state.last_doc_type,
            st.session_state.last_terms,
        )
        st.download_button(
            "📕 Download as .PDF",
            data=pdf_bytes,
            file_name=f"{safe_filename}.pdf",
            mime="application/pdf",
        )
else:
    st.info("Fill in the fields above and click 'Generate Document' to start.")
