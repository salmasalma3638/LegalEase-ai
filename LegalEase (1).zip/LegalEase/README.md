# LegalEase — AI Legal Document Generator

Generates draft legal documents (employment contracts, NDAs, leases, service
contracts) from a few structured inputs, using Google Gemini. Users can
preview, edit inline, and download the result as `.txt`, `.docx`, or `.pdf`.

> **This tool produces AI-drafted starting points, not legal advice.**
> Every generated document carries a disclaimer and should be reviewed by a
> licensed attorney before use. This is baked into the prompt, the UI, and
> every exported file — do not remove it.

## Project structure

```
LegalEase/
├── ai_core/
│   ├── __init__.py
│   └── gemini_generator.py      # Gemini prompt building + API calls + retries
├── legalEaseAPI/
│   ├── __init__.py
│   ├── main.py                  # FastAPI app, CORS
│   └── routes.py                # /generate endpoint, request validation
├── frontend/
│   ├── __init__.py
│   ├── app.py                   # Streamlit UI
│   └── formatters.py            # sanitize_text, format_docx/pdf/html
├── Image/
│   └── Logo.png                 # placeholder logo (swap with your own)
├── config.py                    # shared settings, loaded from .env
├── requirements.txt
├── .env.example                 # copy to .env and fill in your API key
├── .gitignore
├── run_backend.sh
├── run_frontend.sh
├── test_smoke.py                # offline sanity checks, no API calls
└── README.md
```

## 1. Prerequisites

- Python 3.10+
- A Gemini API key from https://aistudio.google.com/app/apikey
- VS Code with the **Python** extension (recommended, not required)

## 2. Setup (VS Code / terminal)

```bash
# 1. Open the LegalEase folder in VS Code: File > Open Folder...

# 2. Create and activate a virtual environment
python -m venv venv

# Windows (PowerShell):
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 3. In VS Code, select the venv interpreter:
#    Ctrl+Shift+P -> "Python: Select Interpreter" -> choose ./venv

# 4. Install dependencies
pip install -r requirements.txt

# 5. Configure your API key
cp .env.example .env        # Windows: copy .env.example .env
# then open .env and paste your real GEMINI_API_KEY
```

**Never commit your `.env` file** — it's already in `.gitignore`.

## 3. Run it

Open two terminals in VS Code (Terminal > Split Terminal), both from the
project root with the venv activated.

**Terminal 1 — backend:**
```bash
uvicorn legalEaseAPI.main:app --reload
# or: ./run_backend.sh
```
Confirm it's up: open http://localhost:8000/ — you should see a welcome
JSON message. Interactive API docs: http://localhost:8000/docs

**Terminal 2 — frontend:**
```bash
streamlit run frontend/app.py
# or: ./run_frontend.sh
```
This opens the UI at http://localhost:8501

## 4. Using the app

1. Pick a **Document Type** (Employment Contract, NDA, Lease, etc.).
2. Fill in **Parties Involved**, **Governing Law / Jurisdiction** (optional
   but recommended — leaving it blank produces a placeholder instead of a
   guessed state/country), **Terms & Conditions** (semicolon-separated),
   and **Effective Date**.
3. Click **Generate Document**.
4. Review the preview, click **Click to Edit Document** to make changes.
5. Download as `.txt`, `.docx`, or `.pdf`.

## 5. Testing

**Offline smoke test** (no API calls, no cost — checks formatters and prompt
construction only):
```bash
python test_smoke.py
```

**Backend health check:**
```bash
curl http://localhost:8000/health
```

**End-to-end generation via curl** (this does call Gemini):
```bash
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{
        "document_type": "Non-Disclosure Agreement",
        "parties": "Jane Doe (Freelancer), Acme Corp (Client)",
        "terms": "Confidentiality for 2 years; No disclosure to third parties",
        "dates": "January 1, 2027",
        "jurisdiction": "State of California, USA"
      }'
```

**Manual UI test checklist:**
- [ ] Generate one document of each type (Employment, NDA, Lease)
- [ ] Leave jurisdiction blank once — confirm the output uses a placeholder,
      not an invented location
- [ ] Edit the generated text and confirm the edit is reflected in all three
      downloads
- [ ] Download `.txt`, `.docx`, `.pdf` and confirm each opens correctly and
      shows the disclaimer
- [ ] Stop the backend and click Generate — confirm the UI shows a clear
      connection error instead of crashing

## 6. Notes on what was hardened vs. the original spec

- **Per-document-type prompts** instead of one generic prompt, so NDAs,
  leases, and employment contracts each get their required clauses.
- **Jurisdiction field** added — the model is instructed to placeholder
  instead of guessing governing law when it's not supplied.
- **Retry + error handling** around the Gemini call (`DocumentGenerationError`),
  surfaced as clean HTTP 502s instead of server crashes.
- **CORS** configured so the Streamlit frontend (port 8501) can call the
  FastAPI backend (port 8000).
- **`fpdf2`** used instead of the unmaintained `fpdf`.
- **Disclaimer** embedded in the prompt output, the UI, and the footer of
  every exported `.docx`/`.pdf`.
- Logo is optional — the app degrades gracefully (text header instead) if
  `Image/Logo.png` is missing or unreadable.

## 7. Before using this beyond a local demo

This is a solid foundation, not a production-ready legal product. Before
any real users touch it, at minimum add: authentication/rate-limiting on
`/generate`, an audit log of generated documents, and a legal review of the
disclaimer language and prompt guardrails by an actual attorney.
