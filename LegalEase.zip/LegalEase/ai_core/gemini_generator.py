from google import genai
import config


class GeminiDocumentGenerator:
    def __init__(self, model_name: str | None = None):
        if not config.GEMINI_API_KEY:
            raise RuntimeError("GEMINI_API_KEY is missing. Add it to your .env file.")
        self.client = genai.Client(api_key=config.GEMINI_API_KEY)
        self.model_name = model_name or config.GEMINI_MODEL

    def generate_document(self, document_type, parties, terms, dates):
        bullets = "\n".join(f"- {t.strip()}" for t in terms.split(";") if t.strip())
        prompt = (
            f"Generate a comprehensive legal document titled '{document_type}'.\n"
            f"Involved parties: {parties}\n"
            f"Effective Date: {dates}\n"
            f"Terms and conditions:\n{bullets}\n"
            "Ensure formal legal structure with multiple numbered sections and legal clauses. "
            "Use plain text only (no markdown symbols), put each section heading on its own line "
            "ending with a colon, use [square brackets] for any missing details, and end with a "
            "signature block."
        )
        response = self.client.models.generate_content(model=self.model_name, contents=prompt)
        return response.text
