import html
import io
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF

import config

REPLACEMENTS = {"\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
                "\u2013": "-", "\u2014": "-", "\u2022": "-", "\u00a0": " "}


def sanitize_text(text: str) -> str:
    """Remove typographic quotes and markdown symbols for clean formatting."""
    for old, new in REPLACEMENTS.items():
        text = text.replace(old, new)
    text = re.sub(r"\*\*|__|`", "", text)
    text = re.sub(r"^\s{0,3}#{1,6}\s*", "", text, flags=re.M)
    text = re.sub(r"^\s*\*\s+", "- ", text, flags=re.M)
    return text.strip()


def is_heading(line: str) -> bool:
    return bool(re.match(r"^\d+\.\s", line) or (line.endswith(":") and len(line) < 80)
                or (line.isupper() and len(line) < 80))


def split_terms(terms: str) -> list[str]:
    return [t.strip() for t in terms.split(";") if t.strip()]


def format_docx(text: str, doc_type: str, terms: str = "") -> bytes:
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name, normal.font.size = "Times New Roman", Pt(12)

    if config.LOGO_PATH.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(config.LOGO_PATH), width=Inches(2))
    title = doc.add_heading(doc_type.title(), 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    for line in text.split("\n"):
        line = line.strip()
        if line:
            doc.add_paragraph().add_run(line).bold = is_heading(line)

    items = split_terms(terms)
    if items:
        doc.add_heading("Summary of Key Terms", level=2)
        table = doc.add_table(rows=1, cols=2)
        table.style = "Table Grid"
        table.rows[0].cells[0].text, table.rows[0].cells[1].text = "No.", "Term"
        for i, item in enumerate(items, 1):
            cells = table.add_row().cells
            cells[0].text, cells[1].text = str(i), item

    footer = doc.sections[0].footer.paragraphs[0]
    footer.text = config.FOOTER_TEXT
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _latin1(s: str) -> str:
    return s.encode("latin-1", "replace").decode("latin-1")


class LegalPDF(FPDF):
    def header(self):
        if config.LOGO_PATH.exists():
            self.image(str(config.LOGO_PATH), x=(self.w - 35) / 2, y=8, w=35)
            self.set_y(30)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, _latin1(config.FOOTER_TEXT), align="C")


def format_pdf(text: str, doc_type: str) -> bytes:
    pdf = LegalPDF()
    pdf.set_auto_page_break(auto=True, margin=20)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, _latin1(doc_type.title()), align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        pdf.set_font("Helvetica", "B" if is_heading(line) else "", 11)
        pdf.multi_cell(0, 6, _latin1(line), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)
    return bytes(pdf.output())


def format_html_preview(text: str) -> str:
    parts = []
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        safe = html.escape(line)
        parts.append(f"<p><b>{safe}</b></p>" if is_heading(line) else f"<p>{safe}</p>")
    return "".join(parts)
