import re
import sys
from pathlib import Path

import requests
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config
from ai_core.generator import sanitize_text, format_docx, format_pdf, format_html_preview

st.set_page_config(page_title="LegalEase", layout="centered")

if config.LOGO_PATH.exists():
    _, col2, _ = st.columns([1, 2, 1])
    with col2:
        st.image(str(config.LOGO_PATH), use_container_width=True)
st.markdown("<h2 style='text-align: center;'>AI Legal Document Generator</h2>", unsafe_allow_html=True)

document_type = st.text_input("Document Type (Ex: Agreement, Contract, NDA)")
parties = st.text_area("Parties Involved")
terms = st.text_area("Terms & Conditions (Use semicolons for bullet points)")
dates = st.text_input("Effective Date")

if st.button("Generate Document"):
    if not all(v.strip() for v in (document_type, parties, terms, dates)):
        st.warning("Please fill in all fields.")
    else:
        with st.spinner("Generating your document..."):
            try:
                resp = requests.post(f"{config.API_URL}/generate", timeout=180, json={
                    "document_type": document_type, "parties": parties,
                    "terms": terms, "dates": dates})
                resp.raise_for_status()
                st.session_state.generated_text = sanitize_text(resp.json()["document"])
                st.session_state.doc_type, st.session_state.terms = document_type, terms
                st.session_state.show_edit = False
            except requests.HTTPError as e:
                st.error(f"Backend error: {e.response.text}")
            except requests.RequestException as e:
                st.error(f"Could not reach the backend at {config.API_URL}. Is uvicorn running? ({e})")
elif "generated_text" not in st.session_state:
    st.info("Click 'Generate Document' to start")

if "generated_text" in st.session_state:
    st.success("Document Generated Successfully!")
    styled = format_html_preview(st.session_state.generated_text)
    st.markdown(
        "<div style='background:#0e1525;color:#e6e6e6;padding:16px;border-radius:8px;"
        f"height:350px;overflow-y:auto;'>{styled}</div>", unsafe_allow_html=True)

    if st.button("✏️ Click to Edit Document"):
        st.session_state.show_edit = not st.session_state.get("show_edit", False)
    if st.session_state.get("show_edit"):
        st.session_state.generated_text = st.text_area(
            "Edit Document Below:", st.session_state.generated_text, height=300)

    text, dtype = st.session_state.generated_text, st.session_state.doc_type
    name = re.sub(r"\W+", "_", dtype.strip()).lower() or "document"
    st.download_button("📄 Download as .TXT", data=text, file_name=f"{name}.txt", mime="text/plain")
    st.download_button("📝 Download as .DOCX", data=format_docx(text, dtype, st.session_state.terms),
                       file_name=f"{name}.docx",
                       mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    st.download_button("📕 Download as .PDF", data=format_pdf(text, dtype),
                       file_name=f"{name}.pdf", mime="application/pdf")
